import React from 'react'

export default function DoctorNavBar() {
  return (
    <div>DoctorNavBar</div>
  )
}
