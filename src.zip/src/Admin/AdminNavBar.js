import React from 'react'

export default function AdminNavBar() {
  return (
    <div>AdminNavBar</div>
  )
}
