import React from 'react'

export default function PatientProfile() {
  return (
    <div>PatientProfile</div>
  )
}
