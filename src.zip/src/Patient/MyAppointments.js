import React from 'react'

export default function MyAppointments() {
  return (
    <div>MyAppointments</div>
  )
}
